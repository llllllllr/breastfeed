const app = getApp();

Page({
  data: {
    playClass: null,
    course_series:"8个关键发育点，养出漂亮宝宝"
  },
  onLoad: function() {
    console.log(app.globalData.url)
  this.setData({
    playClass: app.globalData.url  
//重点！！少了这句不行！！
  })
    }

})