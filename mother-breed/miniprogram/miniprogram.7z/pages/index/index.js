//index.js
//获取应用实例
const app = getApp();
console.log("测试----------"+app.globalData.class_num);
Page({
  data: {
      item:0,
      tab:0,
      id:0,
  playList:[
      {id:1,title:'Dawn of us',singer:'王嘉尔',src:'http://localhost:1314/王嘉尔 - Dawn of us.mp3',coverImgUrl:'../../images/cover.jpg'},
      {id:2,title:'여행 (旅行)',singer:'脸红的思春期',src:'http://localhost:1314/脸红的思春期 - 여행 (旅行).mp3',coverImgUrl:'../../images/cover.jpg'},
      {id:3,title:'发如雪',singer:'周杰伦',src:'http://localhost:1314/周杰伦 - 发如雪.mp3',coverImgUrl:'../../images/cover.jpg'},
      {id:4,title:'Fire',singer:'王一博',src:'http://localhost:1314/王一博 - Fire.mp3',coverImgUrl:'http://localhost:1314/王一博-fire.JPG'},
      ],
      state:'paused',
      playIndex:0,
      play:{
          currentTime:'00:00',
          duration:'00:00',
          percent:0,
          title:'',
          singer:'',
          coverImgUrl:'../../images/cover.jpg'
      },
      article:[
          {src:'../../images/cover.jpg',title:'文章1标题',content:'这是内容这是内容这是内容,点击进入具体文章'}
    ],

      //视频页video
      videos: [{
        video_id: 'mpVideo0',
        url: 'http://wxsnsdy.tc.qq.com/105/20210/snsdyvideodownload?filekey=30280201010421301f0201690402534804102ca905ce620b1241b726bc41dcff44e00204012882540400&bizid=1023&hy=SH&fileparam=302c020101042530230204136ffd93020457e3c4ff02024ef202031e8d7f02030f42400204045a320a0201000400',
      }, {
        video_id: 'mpVideo1',
          url: 'http://wxsnsdy.tc.qq.com/105/20210/snsdyvideodownload?filekey=30280201010421301f0201690402534804102ca905ce620b1241b726bc41dcff44e00204012882540400&bizid=1023&hy=SH&fileparam=302c020101042530230204136ffd93020457e3c4ff02024ef202031e8d7f02030f42400204045a320a0201000400',
      }, {
  
        video_id: 'mpVideo2',
          url: 'http://wxsnsdy.tc.qq.com/105/20210/snsdyvideodownload?filekey=30280201010421301f0201690402534804102ca905ce620b1241b726bc41dcff44e00204012882540400&bizid=1023&hy=SH&fileparam=302c020101042530230204136ffd93020457e3c4ff02024ef202031e8d7f02030f42400204045a320a0201000400',
      }, {
  
  
        video_id: 'mpVideo3',
          url: 'http://wxsnsdy.tc.qq.com/105/20210/snsdyvideodownload?filekey=30280201010421301f0201690402534804102ca905ce620b1241b726bc41dcff44e00204012882540400&bizid=1023&hy=SH&fileparam=302c020101042530230204136ffd93020457e3c4ff02024ef202031e8d7f02030f42400204045a320a0201000400',
      }, {
  
        video_id: 'mpVideo4',
          url: 'http://wxsnsdy.tc.qq.com/105/20210/snsdyvideodownload?filekey=30280201010421301f0201690402534804102ca905ce620b1241b726bc41dcff44e00204012882540400&bizid=1023&hy=SH&fileparam=302c020101042530230204136ffd93020457e3c4ff02024ef202031e8d7f02030f42400204045a320a0201000400',
      }, {
  
        video_id: 'mpVideo5',
          url: 'http://wxsnsdy.tc.qq.com/105/20210/snsdyvideodownload?filekey=30280201010421301f0201690402534804102ca905ce620b1241b726bc41dcff44e00204012882540400&bizid=1023&hy=SH&fileparam=302c020101042530230204136ffd93020457e3c4ff02024ef202031e8d7f02030f42400204045a320a0201000400',
      }, {
  
        video_id: 'mpVideo6',
          url: 'http://wxsnsdy.tc.qq.com/105/20210/snsdyvideodownload?filekey=30280201010421301f0201690402534804102ca905ce620b1241b726bc41dcff44e00204012882540400&bizid=1023&hy=SH&fileparam=302c020101042530230204136ffd93020457e3c4ff02024ef202031e8d7f02030f42400204045a320a0201000400',
      }, {
  
        video_id: 'mpVideo7',
          url: 'http://wxsnsdy.tc.qq.com/105/20210/snsdyvideodownload?filekey=30280201010421301f0201690402534804102ca905ce620b1241b726bc41dcff44e00204012882540400&bizid=1023&hy=SH&fileparam=302c020101042530230204136ffd93020457e3c4ff02024ef202031e8d7f02030f42400204045a320a0201000400',
      }],
     
    
  },

  onLoad: function () {
  },

//   全局
    audioCtx:null,
        onReady:function(){
   // 创建音频播放对象实例
  this.audioCtx= wx.createInnerAudioContext();
  //下面的this?????
  var that=this;
   //音频播放失败
    this.audioCtx.onError(function () {
        console.log('播放失败:'+that.audioCtx.src)
    });
    //完整播放完
    this.audioCtx.onEnded(function () {
        //切换到下一首
       that.next();
    });
    this.audioCtx.onPlay(function () {

    });
    //自动更新播放速度
     this.audioCtx.onTimeUpdate(function () {
         that.setData({
             'play.duration':formatTime(that.audioCtx.duration),
             'play.currentTime':formatTime(that.audioCtx.currentTime),
             'play.percent':that.audioCtx.currentTime/that.audioCtx.duration*100
         })
     });
       this.setMusic(0);
     //格式化时间
       function formatTime(time) {
           var minute=Math.floor(time/60)%60;
           var second=Math.floor(time)%60;
           return (minute<10?'0'+minute:minute)+':'+(second<10?'0'+second:second)
       }
},
    handleVideoScroll: function () {
        const currentId = this.data.videos[this.data.currentPlayVideoIndex].video_id;
        // 关键代码
        // relativeToViewport 这里指定对比的就是viewport,viewport的意思就是document中的可视区域

        this.observerObj = wx.createIntersectionObserver().relativeToViewport();
        console.log('listen ' + currentId);
        // 监听目标视频跟viewport相交区域的变化
        this.observerObj.observe(`#${currentId}`, this.controlVideos);
    },

      setMusic:function(index){
      var music=this.data.playList[index];
      this.audioCtx.src=music.src;
      this.setData({
          playIndex:index,
          'play.title':music.title,
          'play.singer':music.singer,
          'play.coverImgUrl':music.coverImgUrl,
          'play.currentTime':'00:00',
          'play.duration':'00:00',
          'play.percent':0
      })
    },
     next:function(){
   //判断是否为列表的最后一首，若是则回到第一首

   var index=this.data.playIndex>=this.data.playList.length-1?0:this.data.playIndex+1;
         this.setMusic(index);
   //若当前状态为暂停则不立即播放，若是播放状态则播放///用于下一首的图标按钮点击
    if(this.data.state==='running') this.play();
   },

sliderChange:function(e){
      var second=e.detail.value*this.audioCtx.duration/100;
      this.audioCtx.seek(second);
},

    /**以下都是swiper切换用函数**/
    changeItem:function (e) {
        var item=this.data.item;
        this.setData({
            item:e.target.dataset.item,
            // tab:e.target.dataset.item
        });
        //
        // console.log(item);
    },
    changeTab:function (e) {
        var tab=this.data.tab;
        this.setData({
            tab:e.detail.current
        });
        console.log(tab);
    },
    changePage:function (e) {
        var item=this.data.item;
        this.setData({
            item:e.dataset.page
        })
    },
    play:function(){
    this.audioCtx.play();
    this.setData({state:'running'});
    },
    pause:function () {
        this.audioCtx.pause();
        this.setData({state:'paused'});
    },

    // 转到图文详情页1/2/3
    imageText1:function(){
    wx.navigateTo({
        url: 'detailTuWen'
    })
    },
    imageText2:function(){
        wx.navigateTo({
            url: 'detailTuWen'
        })
        },
        imageText3:function(){
            wx.navigateTo({
                url: 'detailTuWen'
            })
            },

    // video视频页
//暂无函数
   
   //微课频道播放视频
   play_class:function(e){
     app.globalData.class_num = e.currentTarget.dataset.item
     var class_index = app.globalData.class_num;
     var index = parseInt(class_index);
     var playClass = app.mini_class[index].url;
     app.globalData.url = playClass;

     console.log("ceshi "+app.globalData.url);
     wx.navigateTo({
       url: '../miniclass/class',
     })

   }
}
);

