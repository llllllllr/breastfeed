//app.js
App({
  //微课class
  mini_class: [{
    class_id: 1,
    url: 'http://localhost:1314/class1.mp4',
  }, {
    class_id: 2,
      url: 'http://wxsnsdy.tc.qq.com/105/20210/snsdyvideodownload?filekey=30280201010421301f0201690402534804102ca905ce620b1241b726bc41dcff44e00204012882540400&bizid=1023&hy=SH&fileparam=302c020101042530230204136ffd93020457e3c4ff02024ef202031e8d7f02030f42400204045a320a0201000400',
  }, {

    class_id: 3,
    url: 'http://localhost:1314/class1.mp4',
  }, {
    class_id: 4,
    url: 'http://localhost:1314/class1.mp4',
  }],

    globalData: {
    class_num: null,
    url:null
  },
  onLaunch: function () {
    
    if (!wx.cloud) {
      console.error('请使用 2.2.3 或以上的基础库以使用云能力')
    } else {
      wx.cloud.init({
        // env 参数说明：
        //   env 参数决定接下来小程序发起的云开发调用（wx.cloud.xxx）会默认请求到哪个云环境的资源
        //   此处请填入环境 ID, 环境 ID 可打开云控制台查看
        //   如不填则使用默认环境（第一个创建的环境）
        // env: 'my-env-id',
        traceUser: true,
      })
    }
  
  }
})
